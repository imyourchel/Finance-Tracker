const cron = require("node-cron");
const Recurring = require("../models/Recurring");
const Transaction = require("../models/Transaction");
const Wallet = require("../models/Wallet");
const Budget = require("../models/Budget");

// Jalankan setiap hari jam 00:05
cron.schedule("5 0 * * *", async () => {
    const today = new Date();
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());

    // Cari tagihan rutin yang aktif dan sudah waktunya dijalankan (nextRunDate <= hari ini)
    const recurrings = await Recurring.find({
        isActive: true,
        nextRunDate: { $lte: todayStart }
    });

    for (const rec of recurrings) {
        await Transaction.create({
            user: rec.user,
            wallet: rec.wallet,
            type: rec.type,
            amount: rec.amount,
            category: rec.category,
            description: rec.description + " (recurring)",
            date: todayStart,
            isRecurring: true,
            recurringId: rec._id,
        });

        // Update saldo wallet
        const wallet = await Wallet.findById(rec.wallet);
        if (wallet) {
            wallet.balance += rec.type === "income" ? rec.amount : -rec.amount;
            await wallet.save();
        }

        // Tentukan tanggal run berikutnya
        const next = new Date(rec.nextRunDate);
        if (rec.frequency === "daily") {
            next.setDate(next.getDate() + 1);
        } else if (rec.frequency === "weekly") {
            next.setDate(next.getDate() + 7);
        } else if (rec.frequency === "monthly") {
            next.setMonth(next.getMonth() + 1);
        } else if (rec.frequency === "yearly") {
            next.setFullYear(next.getFullYear() + 1);
        }

        rec.lastRunDate = todayStart;
        rec.nextRunDate = next;

        // Nonaktifkan jika melewati endDate
        if (rec.endDate && next > rec.endDate) {
            rec.isActive = false;
        }

        await rec.save();
    }
});

// Jalankan tanggal 1 setiap bulan jam 00:10
cron.schedule("10 0 1 * *", async () => {
    const now = new Date();
    const lastMonth = now.getMonth() === 0 ? 12 : now.getMonth();
    const lastYear = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear();
    const thisMonth = now.getMonth() + 1;
    const thisYear = now.getFullYear();

    const budgets = await Budget.find({ rollover: true, month: lastMonth, year: lastYear });

    for (const b of budgets) {
        const sisa = b.limit - b.spent;
        if (sisa <= 0) continue;

        const existing = await Budget.findOne({
            user: b.user, category: b.category,
            month: thisMonth, year: thisYear,
        });
        if (existing) {
            existing.limit += sisa;
            await existing.save();
        }
    }
});